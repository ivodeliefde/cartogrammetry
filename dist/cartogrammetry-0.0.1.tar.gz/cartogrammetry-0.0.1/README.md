# Cartogrammetry

A Python package for creating block or circle style cartograms.

![img1](https://github.com/ivodeliefde/cartogrammetry/blob/master/imgs/cartogram_example_1.PNG?raw=true)

![img2](https://github.com/ivodeliefde/cartogrammetry/blob/master/imgs/cartogram_example_2.PNG?raw=true)

## Documentation

Check out the documentation [here](https://ivodeliefde.github.io/cartogrammetry/).