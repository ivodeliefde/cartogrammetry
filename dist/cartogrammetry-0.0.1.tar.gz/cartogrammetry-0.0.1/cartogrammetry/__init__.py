#!/usr/bin/env python3

"""Init script
"""

from .create import Cartogram, create_block
from .solve import Solver
